# -*- coding: utf-8 -*-
import sys
import re
import os
import subprocess
import fnmatch

DEBUG = True

THISPATH = os.path.dirname(os.path.realpath(__file__))

def split_cmd(cmds):
    """split cmd to list, for subprocess"""
    if isinstance(cmds, basestring):
        cmds = cmds.split()
    else:
        cmds = list(cmds)
    return cmds

def start_cmd(cmds, serialno=None):
    """
    start a subprocess to run adb cmd
    device: specify -s serialno if True
    """
    cmds = split_cmd(cmds)
    prefix = ['adb']
    if serialno:
        prefix += ['-s', serialno]

    cmds = prefix + cmds
    if DEBUG:
        print ' '.join(cmds)
        sys.stdout.flush()
    proc = subprocess.Popen(
        cmds,
        stdout=subprocess.PIPE,
        stdin=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True
    )
    return proc

def cmd(cmds, serialno=None):
    """
    get adb cmd output
    device: specify -s serialno if True
    """
    proc = start_cmd(cmds, serialno)
    stdout, stderr = proc.communicate()
    # if proc.returncode > 0:
    #     raise RuntimeError("cmd error")
    return stdout

def shell(cmds, serial, not_wait=False):
    """
    adb shell
    not_wait: 
        return subprocess if True
        return output if False
    """
    if isinstance(cmds, basestring):
        cmds = 'shell '+ cmds
    else:
        cmds = ['shell'] + list(cmds)
    if not_wait:
        return start_cmd(cmds, serial)
    else:
        return cmd(cmds, serial)


def devices(state=None):
    """adb devices"""
    patten = re.compile(r'^[\w\d.:-]+\t[\w]+$')
    device_list = []
    output = cmd("devices")
    for line in output.splitlines():
        line = line.strip()
        if not line or not patten.match(line):
            continue
        serialno, cstate = line.split('\t')
        if state and cstate != state:
            continue
        device_list.append((serialno, cstate))
    return device_list

def clear(serial, ndkCmd):
	ps = shell("ps", serial)
	for line in ps.splitlines():
		if '/data/local/tmp/'+ndkCmd in line:
			pid = line[10:15]
			shell('kill %s' % (pid), serial)
	shell("rm /data/local/tmp/%s" % ndkCmd, serial)

def getprop(key, serial):
    res = shell(['getprop',key], serial)
    res = res.rstrip('\r\n')
    return res
    

if __name__ == '__main__':
    option = 1
    if len(sys.argv) > 1:
        if sys.argv[1] == "remove":
            option = 2

    serial = None
    devs = devices(state='device')
    if not serial:
        try:
            serial = devs[0][0]
        except:
            print "*******************"
            print u"*ADB  未识别到设备*"
            print "*******************"
    else: 
        for (serialno, st) in devs:
            if not fnmatch.fnmatch(serialno, serial):
                continue
            if st != 'device':
                raise RuntimeError("Device status not good: %s" % (st,))
            serial = serialno
            break
    if serial is None:
        raise RuntimeError("Device not found!")

    ndkCmds = ['lambo-cmd-main', 'daemonize']
    #ndkCmds = ['lambo-cmd', 'LamboServer']

    for ndkCmd in ndkCmds:
        clear(serial, ndkCmd)

        if option == 2:
            continue

        abi = getprop("ro.product.cpu.abi", serial)
        sdk = int(getprop("ro.build.version.sdk", serial))

        if abi not in ("armeabi", "armeabi-v7a", "mips", "x86"):
            abi = "armeabi-v7a"
        print abi, sdk
        if sdk >= 16:
            binfile = ndkCmd
        else:
            binfile = ndkCmd+ "-nopie"

        device_dir = "/data/local/tmp"
        path = os.path.join(THISPATH, "libs", abi, binfile).replace("\\", r"\\")
        cmd("push %s %s/%s" % (path, device_dir, ndkCmd), serial) 
        shell("chmod 755 %s/%s" % (device_dir, ndkCmd), serial)
        #后台运行cmd server
        proc = start_cmd("shell", serial)
        proc.stdin.write('%s/%s &\n' % (device_dir, ndkCmd))
	
